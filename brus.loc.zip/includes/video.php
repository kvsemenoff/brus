<section class="section section_padding dd-wrap_video">
	<div class=" container">
		<div class="row">
			<div class="col-md-12">
				<div class="dd-video_v">
					<iframe width="100%" height="415" src="https://www.youtube.com/embed/zWBRry4cO9g" frameborder="0" allowfullscreen></iframe>
				</div>
			</div>
		</div>
	</div>
</section>

<section class="dd-wrap_ot">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<h5 class="dd-pr-h2 dd-txt_ot">Профилированный брус отзывы</h5>
				<div class="dd-txt_pb ">
					<p>Рыбным текстом называется текст, служащий для временного наполнения макета в публикациях или производстве веб-сайтов,
						пока финальный текст еще не создан.
					</p>
				</div>

				<div class="dd-box-wrap_pb">
					<div class="dd-box_pb">
						<img class="img-responsive" src="img/d1.jpg" alt="">
					</div>
					<div class="dd-box_pb dd-box-green_pb dd-box_pb_red">
						<h2>Непродуваемый замок</h2>
						<p>Рыбным текстом называется текст, служащий для временного наполнения макета в публикациях или производстве веб-сайтов, пока финальный текст еще не создан. Рыбный текст также известен как текст-заполнитель или же текст-наполнитель. Иногда текст-«рыба» также используется композиторами при написании музыки. Они напевают его перед тем, как сочинены соответствующие слова. Уже в 16-том веке рыбные тексты имели широкое распространение у печатников.
						</p>
					</div>
					<div class="clearfix"></div>
				</div>


				<div class="dd-box-wrap_pb">
					<div class="dd-box_pb dd-box_pb_2">
						<img class="img-responsive" src="img/d2.jpg" alt="">
					</div>
					<div class="dd-box_pb dd-box-green_pb dd-box-green_pb_2 dd-box_pb_red">
						<h2>стены без дополнительной отделки</h2>
						<p>Рыбным текстом называется текст, служащий для временного наполнения макета в публикациях или производстве веб-сайтов, пока финальный текст еще не создан. Рыбный текст также известен как текст-заполнитель или же текст-наполнитель. Иногда текст-«рыба» также используется композиторами при написании музыки. Они напевают его перед тем, как сочинены соответствующие слова. Уже в 16-том веке рыбные тексты имели широкое распространение у печатников.
						</p>
					</div>
					<div class="clearfix"></div>
				</div>

			</div>
		</div>
	</div>	
</section>