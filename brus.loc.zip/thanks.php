<!doctype html>
<html lang="ru">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Спасибо за заявку</title>

	<?php require_once('includes/header.php'); ?>

	<section class="db-thanks-section">						
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<div class="db-spasibo">
						<span>Спасибо за заявку!</span><br>
						<span>Наш менеджер свяжется с вами в ближайшее время!</span>
					</div>
					<a href="/" class="db-spasibo-a">Перейти на главную</a>
				</div>
			</div>
		</div>
	</section>
</body>
</html>