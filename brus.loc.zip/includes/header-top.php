<section class="section section_padding section_db-header">
	<div class=" container">
		<div class="row">
			<div class="all-container">
				<div class="col-md-6">
					<div class="db-one">
						<a href="#"><img src="img/brus-log.png" alt="img"></a> 
						<p>Профилированный брус<br>
							Собственное производство в Новосибирске<br>
							Полный цикл деревообработки от круглого леса<br>
							Готовность бруса от 1 дня</p>
							<div class="clearfix"></div>
						</div>
					</div>
					<div class="col-md-6">
						<div class="db-two">
							<p>
								<span>+7 (383) 377-75-41 </span> <a href="#log-in" name="modal">Перезвоним за 30 секунд</a>
							</p>
						</div>
					</div>
					<div class="clearfix"></div>
				</div>
			</div>
		</div>
	</section>
	
	<section class="db-num_menu">	
	<div class="db-burger">
			<img src="img/burger.png" alt="img" >
		</div>	
		<ul class="db-menu">
			<li><a href="index.php">Главная</a></li>
			<li><a href="doma.php">дома из профилированного бруса</a></li>
			<li><a href="bani.php">бани из профилированного бруса</a></li>
			<li><a href="price.php">цена</a></li>
			<li><a href="calculator.php">онлайн калькулятор</a></li>
			<li><a href="contacts.php">контакты</a></li>
		</ul>
		<div class="clearfix"></div>
	</section>
	<section class="db-num_menu2">	
		<ul class="db-menu">
			<li><a href="index.php">Главная</a></li>
			<li><a href="doma.php">дома из профилированного бруса</a></li>
			<li><a href="bani.php">бани из профилированного бруса</a></li>
			<li><a href="price.php">цена</a></li>
			<li><a href="calculator.php">онлайн калькулятор</a></li>
			<li><a href="contacts.php">контакты</a></li>
		</ul>
		<div class="clearfix"></div>
	</section>