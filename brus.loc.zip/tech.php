<?php require_once('includes/header.php'); ?>

<br><br>		
<a href="#" class="button-1">Заказать звонок</a>	
<br><br>	
<h1>профилированный брус</h1>
<br><br>
<div class="h2-wrap">
    <h2>профилированный брус цена в новосибирске</h2>
</div>
<br><br>
<h3>Сухой профилированный брус</h3>
<br><br>	
<form action="#">
	<input type="text" value="" placeholder="Инпут тайп текст">		
	<input type="submit" value="Значение" placeholder="Инпут тайп сабмит">		
</form>		


<?php require_once('includes/footer.php'); ?>

	
</body>
</html>

