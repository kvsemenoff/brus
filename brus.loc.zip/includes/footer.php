<section class="section section_padding section_db-header">
	<div class=" container">
		<div class="row">
			<div class="all-container">
				<div class="col-md-6">
					<div class="db-one">
						<a href="index.php"><img src="img/brus-log.png" alt="img"></a> 
						<p>Профилированный брус<br>
							Собственное производство в Новосибирске<br>
							Полный цикл деревообработки от круглого леса<br>
							Готовность бруса от 1 дня</p>
							<div class="clearfix"></div>
						</div>
					</div>
					<div class="col-md-6">
						<div class="db-two">
							<p>
								<span>+7 (383) 377-75-41</span> <a href="#log-in" name="modal">Перезвоним за 30 секунд</a>
							</p>
						</div>
					</div>
					<div class="clearfix"></div>
				</div>
			</div>
		</div>
	</section>


	<a href="#log-in" name="modal">dfdd</a>

	<div id="mask"></div>

	<div id="log-in" class="window2">
		<div class="sukhoy-form__block dd-pop">
			<p class="sukhoy-getprice">Заказать звонок</p>
			<form method="post" action="#" class="form1 sukhoy-form" >
				<input class="sukhoy-input" type="text" name="uname" placeholder="Ваше Имя" required>
				<input class="sukhoy-input phone" type="text" name="phone" placeholder="Ваш телефон" required>
				<input class="sukhoy-input sukhoy-submit" type="submit" name="submit" value="Отправить">
			</form>
			<p class="sukhoy-secure">Ваши данные в безопасности и не будут переданы третьим лицам</p>
		</div>
	</div>

	<div id="log-in2" class="window2">
		<div class="sukhoy-form__block dd-pop">
			<p class="sukhoy-getprice">Получить расчет</p>
			<form method="post" action="#" class="form1 sukhoy-form" >
				<input class="sukhoy-input" type="text" name="uname" placeholder="Ваше Имя" required>
				<input class="sukhoy-input phone" type="text" name="phone" placeholder="Ваш телефон" required>
				<input class="sukhoy-input sukhoy-submit" type="submit" name="submit" value="Отправить">
			</form>
			<p class="sukhoy-secure">Ваши данные в безопасности и не будут переданы третьим лицам</p>
		</div>
	</div>

	<div id="log-in4" class="window2">
		<div class="sukhoy-form__block dd-pop">
			<p class="sukhoy-getprice">Скачать еще 37 проектов</p>
			<form method="post" action="#" class="form1 sukhoy-form" >
				<input class="sukhoy-input" type="text" name="uname" placeholder="Ваше Имя" required>
				<input class="sukhoy-input phone" type="text" name="phone" placeholder="Ваш телефон" required>
				<input class="sukhoy-input sukhoy-submit" type="submit" name="submit" value="Отправить">
			</form>
			<p class="sukhoy-secure">Ваши данные в безопасности и не будут переданы третьим лицам</p>
		</div>
	</div>

	<div id="log-in3" class="window2">
		<div class="sukhoy-form__block dd-pop">
			<p class="sukhoy-getprice">Получить смету</p>
			<form method="post" action="#" class="form1 sukhoy-form" >
				<input class="sukhoy-input" type="text" name="uname" placeholder="Ваше Имя" required>
				<input class="sukhoy-input phone" type="text" name="phone" placeholder="Ваш телефон" required>
				<input class="sukhoy-input sukhoy-submit" type="submit" name="submit" value="Отправить">
			</form>
			<p class="sukhoy-secure">Ваши данные в безопасности и не будут переданы третьим лицам</p>
		</div>
	</div>