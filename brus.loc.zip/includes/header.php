

	<link rel="stylesheet" href="libs/bootstrap/bootstrap-grid-3.3.1.min.css" />
	<link rel="stylesheet" href="libs/bootstrap/bootstrap.min.css" />
	<link href="//netdna.bootstrapcdn.com/font-awesome/4.6.3/css/font-awesome.css" rel="stylesheet">
	<link rel="stylesheet" href="libs/fancybox/jquery.fancybox.css" />
	<link rel="stylesheet" href="libs/owl.carousel/assets/owl.carousel.css" />
	<link rel="stylesheet" href="libs/slick/slick.css" />

	<!-- <link href="https://fonts.googleapis.com/css?family=Oswald:300,400,500,600,700" rel="stylesheet"> -->

<link href="https://fonts.googleapis.com/css?family=Oswald:200,300,400,500,600,700&amp;subset=cyrillic" rel="stylesheet">
	
	<link rel="shortcut icon" href="favicon.ico" />
	<link rel="stylesheet" href="css/style.css">
    <script src="https://api-maps.yandex.ru/1.1/index.xml" type="text/javascript"></script>
</head>
<body>
	<script src="libs/jquery/jquery-1.11.1.min.js"></script>
	<script src="libs/owl.carousel/owl.carousel.js"></script>
	<script src="libs/slick/slick.min.js"></script>
	<script src="libs/fancybox/jquery.fancybox.pack.js"></script>
	<script src="libs/bootstrap/bootstrap.min.js"></script>
	<script src="js/jquery.maskedinput.min.js"></script>
	<script src="js/common.js"></script>

	<!-- Yandex.Metrika counter -->
	<script type="text/javascript">
	    // (function (d, w, c) {
	    //     (w[c] = w[c] || []).push(function() {
	    //         try {
	    //             w.yaCounter43608829 = new Ya.Metrika({
	    //                 id:43608829,
	    //                 clickmap:true,
	    //                 trackLinks:true,
	    //                 accurateTrackBounce:true,
	    //                 webvisor:true
	    //             });
	    //         } catch(e) { }
	    //     });

	    //     var n = d.getElementsByTagName("script")[0],
	    //         s = d.createElement("script"),
	    //         f = function () { n.parentNode.insertBefore(s, n); };
	    //     s.type = "text/javascript";
	    //     s.async = true;
	    //     s.src = "https://mc.yandex.ru/metrika/watch.js";

	    //     if (w.opera == "[object Opera]") {
	    //         d.addEventListener("DOMContentLoaded", f, false);
	    //     } else { f(); }
	    // })(document, window, "yandex_metrika_callbacks");
	</script>
	<noscript><div><img src="https://mc.yandex.ru/watch/43608829" style="position:absolute; left:-9999px;" alt="" /></div></noscript>
	<!-- /Yandex.Metrika counter -->