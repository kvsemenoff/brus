<!doctype html>
<html lang="ru">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="Профилированный брус в Новосибирске от производителя изготавливает наша компания. Мы уверены в качестве нашего материала, так как для нас крайне важно, чтобы вы получили идеальный результат">
	<title>Профилированный брус в Новосибирске</title>
	
<?php require_once('includes/header.php'); ?>
<?php require_once('includes/header-top.php'); ?>
<?php require_once('includes/first.php'); ?>
<?php require_once('includes/prof.php'); ?>
<?php require_once('includes/prof2.php'); ?>
<?php require_once('includes/suxoy.php'); ?>
<?php require_once('includes/buy.php'); ?>
<?php require_once('includes/video.php'); ?>
<?php require_once('includes/trust.php'); ?>
<?php require_once('includes/find.php'); ?>
<?php require_once('includes/footer.php'); ?>

</body>
</html>