<section class="section section_padding trust">
<div class=" container">
	<div class="row">
	    <div class="col-md-12">
	        <h2 class="trust-title">
	            нам доверяют компании
	        </h2>
	    </div>
		<div class="col-md-4">
		    <div class="trust-item"><img src="img/trust1.png" alt="" class="trust-img"></div>
		</div>
		<div class="col-md-4">
		    <div class="trust-item"><img src="img/trust2.png" alt="" class="trust-img"></div>
		</div>
		<div class="col-md-4">
		    <div class="trust-item"><img src="img/trust3.png" alt="" class="trust-img"></div>
		</div>
	</div>
</div>
</section>
